username=aman and 
pwd=1234
it is totally based on python gui (tkinter).....
After downloading all files firstly run w1.py file
